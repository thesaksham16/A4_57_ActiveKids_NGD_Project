def calculate_points(challenge_level):
    if challenge_level == 1:
        return 10
    elif challenge_level == 2:
        return 20
    elif challenge_level == 3:
        return 30
    else:
        return 50
